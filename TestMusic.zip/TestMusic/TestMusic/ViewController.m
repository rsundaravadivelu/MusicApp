//
//  ViewController.m
//  TestMusic
//
//  Created by MacBookPro4 on 5/23/17.
//  Copyright © 2017 seek. All rights reserved.
//

#import "ViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import <AudioToolbox/AudioToolbox.h>

@interface ViewController ()<MPMediaPickerControllerDelegate,NSObject>
{
    AVPlayer *audioPlayer;
    NSMutableArray *MusicName;
    int i;
    NSTimer *sliderTimer;
    UIActivityIndicatorView *activityView;
}


@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    i=0;
    audioPlayer=nil;
    _transparentView.hidden=NO;
    activityView = [[UIActivityIndicatorView alloc]
        initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    activityView.center=self.view.center;
    [activityView startAnimating];
    [self.transparentView addSubview:activityView];
    
    [self deleteExiting];
}

-(void)deleteExiting
{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSError *error;
    
    NSArray * tempArray = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *docsDir = [tempArray objectAtIndex:0];
    
    NSString *appDir = [docsDir stringByAppendingPathComponent:@"/Music"];
    
    if([fileManager fileExistsAtPath:appDir])
    {
        NSLog([fileManager removeItemAtPath:appDir error:&error]?@"deleted":@"not deleted");
    }
    [self loadDeviceMusic];

}

-(void)loadDeviceMusic
{

    MPMediaQuery *everything = [[MPMediaQuery alloc] init];
    [everything addFilterPredicate:[MPMediaPropertyPredicate predicateWithValue:[NSNumber numberWithBool:NO] forProperty:MPMediaItemPropertyIsCloudItem]];
    NSArray *itemsFromGenericQuery = [everything items];
    MusicName=[[NSMutableArray alloc]init];

    dispatch_queue_t demoQueue = dispatch_queue_create("com.demo.group", DISPATCH_QUEUE_CONCURRENT);
    dispatch_async(demoQueue, ^{
        dispatch_group_t demoGroup = dispatch_group_create();
    
    for (MPMediaItem *song in itemsFromGenericQuery) {
        
        dispatch_group_enter(demoGroup);

    NSURL *assetURL = [song valueForProperty:MPMediaItemPropertyAssetURL];
    AVAsset *asset = [AVAsset assetWithURL:assetURL];
    NSLog(@"songs URL=%@",assetURL);
    
    AVURLAsset *songAsset = [AVURLAsset URLAssetWithURL: assetURL options:nil];
    NSData *d1=[NSData dataWithContentsOfURL:assetURL];
    
    AVAssetExportSession *exporter = [[AVAssetExportSession alloc] initWithAsset: songAsset presetName:AVAssetExportPresetAppleM4A];
        
    exporter.outputFileType = @"com.apple.m4a-audio";
    
    NSError *error;
    NSArray *pathfinalPlist = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *myDocumentsDirectory = [pathfinalPlist objectAtIndex:0];
    NSString *documentsPathlist = [myDocumentsDirectory stringByAppendingPathComponent:@"/Music"];
        
    
    if (![[NSFileManager defaultManager] fileExistsAtPath:documentsPathlist])
        [[NSFileManager defaultManager] createDirectoryAtPath:documentsPathlist withIntermediateDirectories:NO attributes:nil error:&error];
        
    NSString *SharedFinalplistPath = [documentsPathlist stringByAppendingPathComponent:[NSString stringWithFormat:@"/%@",@"MyMusic.plist"]];

    
    NSString * fileName = [NSString stringWithFormat:@"%@.m4a",song.title];
    
    NSString *dataPath = [documentsPathlist stringByAppendingFormat:@"/%@",fileName];
    if(MusicName==nil)
    {
        MusicName = [[NSMutableArray alloc]init];
    }
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    [dic setValue:dataPath forKey:@"MusicPath"];
    [MusicName addObject:dic];
    
    NSURL *exportURL = [NSURL fileURLWithPath:dataPath];
    exporter.outputURL = exportURL;
    
    // do the export
    // (completion handler block omitted)
    
    [exporter exportAsynchronouslyWithCompletionHandler:
     ^{
         NSLog(@"enter exporter");
         dispatch_async(dispatch_get_main_queue(), ^{
             
             int exportStatus = exporter.status;
             
             switch (exportStatus)
             {
                 case AVAssetExportSessionStatusFailed:
                 {
                     NSError *exportError = exporter.error;
                     NSLog (@"AVAssetExportSessionStatusFailed: %@", exportError);
                     break;
                 }
                 case AVAssetExportSessionStatusCompleted:
                 {
                     NSLog (@"AVAssetExportSessionStatusCompleted");
                     break;
                 }
                 case AVAssetExportSessionStatusUnknown:
                 {
                     NSLog(@"AVAssetExportSessionStatusUnknown"); break;
                 }
                 case AVAssetExportSessionStatusExporting:
                 {
                     NSLog(@"AVAssetExportSessionStatusExporting"); break;
                 }
                 case AVAssetExportSessionStatusCancelled:
                 {
                     NSLog(@"AVAssetExportSessionStatusCancelled"); break;
                 }
                 case AVAssetExportSessionStatusWaiting:
                 {
                     NSLog(@"AVAssetExportSessionStatusWaiting"); break;
                 }
                 default:
                 {
                     NSLog(@"didn't get export status"); break;
                 }
             }
         });
         dispatch_group_leave(demoGroup);

     }];
    }
    
    dispatch_group_notify(demoGroup, dispatch_get_main_queue(), ^{
            //NSLog(@"All group tasks are done!");
        
            [activityView stopAnimating];
            _transparentView.hidden=YES;

            [self playMusic];
        });
    });
}

- (void)audioPlayerDidFinishPlaying : (AVAudioPlayer *)player successfully:(BOOL)flag
{
    // Music completed
    NSLog(@"flag:%hhd",flag);
    if (flag)
    {
        NSLog(@"timer invalidate");
        [sliderTimer invalidate];
    }
    audioPlayer=nil;
}

-(void)playMusic
{
    AVPlayer *player;
    NSLog(@"i value:%d",i);
    if(audioPlayer==nil)
    {

    NSURL *path =[NSURL fileURLWithPath:[[MusicName objectAtIndex:i]valueForKey:@"MusicPath"]];
    NSAssert(path, @"URL is nil");

    player = [[AVPlayer alloc] initWithURL:path];
    NSAssert(player, @"player is nil");
    [player play];
    
    audioPlayer = player;
    }
    else
    {
        [audioPlayer play];

    }
   
    sliderTimer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
    
    [self.btnslider addTarget:self action:@selector(sliderChanged:)  forControlEvents:UIControlEventValueChanged];
    
    self.btnslider.minimumValue = 0;
   // NSLog(@"Max:%f",CMTimeGetSeconds(audioPlayer.currentItem.asset.duration));
    self.btnslider.maximumValue = CMTimeGetSeconds(audioPlayer.currentItem.asset.duration);
    NSString *time = [self timeFormatted:self.btnslider.maximumValue];
    self.maxtime.text=time;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)playAction:(id)sender
{
    [self playMusic];
}

- (IBAction)stopAction:(id)sender
{
    [audioPlayer pause];
}

- (IBAction)prevAction:(id)sender
{
    if(i>0)
    {
        i--;
        audioPlayer=nil;
        [self playMusic];
    }
}

- (IBAction)nextAction:(id)sender
{
    if(i<MusicName.count-1)
    {
        i++;
        audioPlayer=nil;
        [self playMusic];
    }
}

- (IBAction)sliderChanged:(UISlider *)sender
{

    int32_t timeScale = audioPlayer.currentItem.asset.duration.timescale;
    [audioPlayer seekToTime:CMTimeMakeWithSeconds(self.        btnslider.value, timeScale)
                 toleranceBefore: kCMTimeZero
                  toleranceAfter: kCMTimeZero
               completionHandler: ^(BOOL finished) {
                    [audioPlayer play];
                }];
}
    
- (void)updateTime
{
        // Updates the slider about the music time
    self.btnslider.value = CMTimeGetSeconds(audioPlayer.currentTime);
    
    NSString *time = [self timeFormatted:self.btnslider.value];
    self.mintime.text = time;
   
    if([time isEqualToString:[self timeFormatted:self.btnslider.maximumValue]])
    {
        audioPlayer=nil;
    }
}

- (NSString *)timeFormatted:(int)totalSeconds
{
    int seconds = totalSeconds % 60;
    int minutes = (totalSeconds / 60) % 60;
        
    return [NSString stringWithFormat:@"%02d:%02d", minutes, seconds];
}


@end

//
//  ViewController.h
//  TestMusic
//
//  Created by MacBookPro4 on 5/23/17.
//  Copyright © 2017 seek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>

@interface ViewController : UIViewController<AVAudioPlayerDelegate>

- (IBAction)prevAction:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnPrev;
- (IBAction)playAction:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnPlay;
- (IBAction)stopAction:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnStop;
@property (strong, nonatomic) IBOutlet UIButton *btnNext;
- (IBAction)nextAction:(id)sender;
@property (strong, nonatomic) IBOutlet UISlider *btnslider;
@property (strong, nonatomic) IBOutlet UILabel *mintime;
@property (strong, nonatomic) IBOutlet UILabel *maxtime;
@property (strong, nonatomic) IBOutlet UIView *transparentView;

@end


//
//  AppDelegate.h
//  TestMusic
//
//  Created by MacBookPro4 on 5/23/17.
//  Copyright © 2017 seek. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

